export const USER = "USER"
export const PRODUCT = "PRODUCT"